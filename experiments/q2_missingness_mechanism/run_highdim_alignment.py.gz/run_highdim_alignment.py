#!/usr/bin/env python3
"""High-dimensional spectral / flue-gas row-alignment experiment.

The six 6C XLSB workbooks are the only inputs. For each control heat, simulate
shared versus independent row-retention masks for the 2047-channel spectrum
and the paired CO2/CO stream, then ask whether spectral transitions add
blocked out-of-sample information about gas transitions beyond gas history.

This is a row-alignment diagnostic, not a reconstruction of missing timestamps.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, rankdata
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from threadpoolctl import threadpool_limits

TARGET = "6C02057"
N_COMPONENTS = 12
ALPHA = 10.0
N_SPLITS = 5
CV_GAP = 5


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def heat_id(path: Path) -> str | None:
    m = re.search(r"Heat No\.\s*(6C\d+)\.xlsb$", path.name)
    return m.group(1) if m else None


def load_heat(path: Path) -> dict:
    frame = pd.read_excel(path, header=None, engine="pyxlsb")
    arr = frame.iloc[1:].to_numpy(dtype=np.float64, copy=True)
    if arr.shape[1] != 2051:
        raise ValueError(f"Unexpected shape {arr.shape} in {path.name}")
    wl = frame.iloc[0, 1:2048].to_numpy(dtype=np.float64, copy=True)
    return {
        "heat": heat_id(path),
        "seq": arr[:, 0].astype(np.int64),
        "X": arr[:, 1:2048],
        "O": arr[:, 2048],
        "CO2": arr[:, 2049],
        "CO": arr[:, 2050],
        "wl": wl,
        "path": str(path),
        "sha256": sha256(path),
        "missing_cells": int(np.isnan(arr).sum()),
    }


def load_heat_cache(cache_path: Path, source_path: Path | None = None) -> dict:
    with np.load(cache_path) as z:
        d = {
            "heat": cache_path.stem, "seq": z["seq"].astype(np.int64),
            "X": z["X"].astype(np.float32, copy=False),
            "O": z["O"].astype(np.float64, copy=False),
            "CO2": z["CO2"].astype(np.float64, copy=False),
            "CO": z["CO"].astype(np.float64, copy=False),
            "wl": z["wl"].astype(np.float64, copy=False),
            "path": str(source_path or cache_path),
            "missing_cells": int(np.isnan(z["X"]).sum() + np.isnan(z["O"]).sum() + np.isnan(z["CO2"]).sum() + np.isnan(z["CO"]).sum()),
        }
    meta_path = cache_path.with_suffix(".json")
    meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
    d["sha256"] = meta.get("sha256") or sha256(source_path or cache_path)
    return d


def fit_spectral_representation(d: dict, seed: int) -> dict:
    """Unsupervised PCA of all frames; gas labels are never used in the fit."""
    X = np.asarray(d["X"], dtype=np.float32)
    # Keep intensity dynamics in one view and remove frame brightness in the other.
    X_log = np.log1p(X)
    X_shape = X / np.maximum(X.sum(axis=1, keepdims=True), 1e-12)
    views = {}
    for name, V in [("intensity", X_log), ("shape", X_shape)]:
        mu = V.mean(axis=0)
        sd = V.std(axis=0)
        sd[sd < 1e-10] = 1.0
        Z = (V - mu) / sd
        pca = PCA(n_components=N_COMPONENTS, svd_solver="randomized", random_state=seed)
        scores = pca.fit_transform(Z)
        score_sd = scores.std(axis=0)
        score_sd[score_sd < 1e-10] = 1.0
        views[name] = scores / score_sd
        d[f"pca_{name}_explained"] = pca.explained_variance_ratio_.tolist()
    d["pc"] = np.column_stack([views["intensity"], views["shape"]])
    # Keep the 2047-channel information in two 12-PC views; one captures
    # log-intensity dynamics and the other captures row-normalized spectral shape.
    d["log_total"] = np.log1p(X.sum(axis=1))
    return d


def regular_mask(n: int, m: int, rng: np.random.Generator) -> np.ndarray:
    phase = rng.random()
    idx = np.floor((phase + np.arange(m)) * n / m).astype(int)
    return np.clip(idx, 0, n - 1)


def markov_mask(n: int, m: int, mean_cycle: float, rng: np.random.Generator) -> np.ndarray:
    keep_rate = m / n
    mean_keep = max(1.01, mean_cycle * keep_rate)
    mean_drop = max(1.01, mean_cycle * (1.0 - keep_rate))
    p_kd = min(1.0, 1.0 / mean_keep)
    p_dk = min(1.0, 1.0 / mean_drop)
    state = bool(rng.random() < keep_rate)
    keep = np.zeros(n, dtype=bool)
    for i in range(n):
        keep[i] = state
        if state and rng.random() < p_kd:
            state = False
        elif not state and rng.random() < p_dk:
            state = True
    diff = int(keep.sum()) - m
    if diff > 0:
        candidates = np.flatnonzero(keep)
        keep[rng.choice(candidates, size=diff, replace=False)] = False
    elif diff < 0:
        candidates = np.flatnonzero(~keep)
        keep[rng.choice(candidates, size=-diff, replace=False)] = True
    idx = np.flatnonzero(keep)
    if len(idx) != m:
        raise RuntimeError("Mask count correction failed")
    return idx


def make_mask(n: int, m: int, mechanism: str, rng: np.random.Generator) -> np.ndarray:
    if mechanism == "random":
        return np.sort(rng.choice(n, size=m, replace=False))
    if mechanism == "regular":
        return regular_mask(n, m, rng)
    if mechanism.startswith("bursty"):
        return markov_mask(n, m, float(mechanism.replace("bursty", "")), rng)
    raise ValueError(mechanism)


def safe_spearman(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    good = np.isfinite(x) & np.isfinite(y)
    if good.sum() < 20 or np.std(x[good]) == 0 or np.std(y[good]) == 0:
        return np.nan
    return float(spearmanr(x[good], y[good]).statistic)


def mean_abs_column_spearman(X: np.ndarray, y: np.ndarray) -> float:
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    good = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    X, y = X[good], y[good]
    if len(y) < 20 or np.std(y) == 0:
        return np.nan
    RX = rankdata(X, axis=0)
    ry = rankdata(y)
    RX -= RX.mean(axis=0, keepdims=True)
    ry -= ry.mean()
    denom = np.sqrt(np.sum(RX * RX, axis=0) * np.sum(ry * ry))
    corrs = np.divide(RX.T @ ry, denom, out=np.full(X.shape[1], np.nan), where=denom > 0)
    return float(np.nanmean(np.abs(corrs)))


def cv_skill_gain(pc: np.ndarray, gas: np.ndarray, alpha: float = ALPHA) -> dict[str, float]:
    """Incremental blocked-CV skill from spectral deltas over a gas-history baseline."""
    pc = np.asarray(pc, float)
    gas = np.asarray(gas, float)
    dgas = np.diff(gas, axis=0)
    dpc = np.diff(pc, axis=0)
    # Predict transition t using gas state at its start and both gas changes up to t-1.
    y = dgas[1:]
    base = np.column_stack([gas[1:-1, 0], gas[1:-1, 1], dgas[:-1, 0], dgas[:-1, 1]])
    spec = dpc[1:]
    if len(y) < 120:
        return {"skill_gain_CO2": np.nan, "skill_gain_CO": np.nan, "skill_gain_mean": np.nan,
                "mse_base_CO2": np.nan, "mse_aug_CO2": np.nan, "mse_base_CO": np.nan, "mse_aug_CO": np.nan}

    splitter = TimeSeriesSplit(n_splits=N_SPLITS, gap=CV_GAP)
    pred_base = np.full_like(y, np.nan, dtype=float)
    pred_aug = np.full_like(y, np.nan, dtype=float)
    for tr, te in splitter.split(base):
        sb = StandardScaler().fit(base[tr])
        sa = StandardScaler().fit(np.column_stack([base[tr], spec[tr]]))
        Btr, Bte = sb.transform(base[tr]), sb.transform(base[te])
        Atr = sa.transform(np.column_stack([base[tr], spec[tr]]))
        Ate = sa.transform(np.column_stack([base[te], spec[te]]))
        for j in range(2):
            ym = float(y[tr, j].mean())
            ys = float(y[tr, j].std())
            if ys < 1e-10:
                ys = 1.0
            yt = (y[tr, j] - ym) / ys
            mb = Ridge(alpha=alpha).fit(Btr, yt)
            ma = Ridge(alpha=alpha).fit(Atr, yt)
            pred_base[te, j] = mb.predict(Bte) * ys + ym
            pred_aug[te, j] = ma.predict(Ate) * ys + ym

    gains, mb_list, ma_list = [], [], []
    for j, name in enumerate(["CO2", "CO"]):
        good = np.isfinite(pred_base[:, j]) & np.isfinite(pred_aug[:, j]) & np.isfinite(y[:, j])
        mb = float(np.mean((y[good, j] - pred_base[good, j]) ** 2))
        ma = float(np.mean((y[good, j] - pred_aug[good, j]) ** 2))
        gain = float(1.0 - ma / mb) if mb > 1e-14 else np.nan
        gains.append(gain); mb_list.append(mb); ma_list.append(ma)
    return {
        "skill_gain_CO2": gains[0], "skill_gain_CO": gains[1],
        "skill_gain_mean": float(np.nanmean(gains)) if np.isfinite(gains).any() else np.nan,
        "mse_base_CO2": mb_list[0], "mse_aug_CO2": ma_list[0],
        "mse_base_CO": mb_list[1], "mse_aug_CO": ma_list[1],
    }


def sequence_metrics(pc: np.ndarray, log_total: np.ndarray, gas: np.ndarray, alpha: float = ALPHA, include_cv: bool = True) -> dict[str, float]:
    pc = np.asarray(pc, float)
    gas = np.asarray(gas, float)
    dgas = np.diff(gas, axis=0)
    dpc = np.diff(pc, axis=0)
    pc_dist = np.sqrt(np.mean(dpc * dpc, axis=1))
    log_total_delta = np.abs(np.diff(log_total))
    if include_cv:
        out = cv_skill_gain(pc, gas, alpha=alpha)
    else:
        out = {}
    out.update({
        "rho_pc_dist_CO2": safe_spearman(pc_dist, np.abs(dgas[:, 0])),
        "rho_pc_dist_CO": safe_spearman(pc_dist, np.abs(dgas[:, 1])),
        "mean_abs_pc_rho_CO2": mean_abs_column_spearman(dpc, dgas[:, 0]),
        "mean_abs_pc_rho_CO": mean_abs_column_spearman(dpc, dgas[:, 1]),
        "rho_log_brightness_CO2": safe_spearman(log_total_delta, np.abs(dgas[:, 0])),
        "rho_log_brightness_CO": safe_spearman(log_total_delta, np.abs(dgas[:, 1])),
        "median_pc_transition_distance": float(np.median(pc_dist)),
    })
    return out


def summarize_target(target_value: float, sim_values: np.ndarray) -> tuple[float, float, float]:
    vals = np.asarray(sim_values, float)
    vals = vals[np.isfinite(vals)]
    if len(vals) == 0 or not np.isfinite(target_value):
        return np.nan, np.nan, np.nan
    pct = (np.sum(vals < target_value) + 0.5 * np.sum(vals == target_value)) / len(vals)
    med = float(np.median(vals))
    q10, q90 = np.quantile(vals, [0.1, 0.9])
    return float(pct), med, float(q90 - q10)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", type=Path)
    ap.add_argument("--cache-dir", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--rep", type=int, default=100)
    ap.add_argument("--seed", type=int, default=20261128)
    ap.add_argument("--target", default=TARGET)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if not args.data_dir and not args.cache_dir:
        ap.error("Provide --data-dir or --cache-dir")
    cache_paths = sorted(args.cache_dir.glob("6C*.npz")) if args.cache_dir else []
    if args.cache_dir:
        if len(cache_paths) != 6:
            raise ValueError(f"Expected six 6C NPZ caches; found {[p.stem for p in cache_paths]}")
        source_by_heat = {}
        if args.data_dir:
            source_by_heat = {heat_id(p): p for p in args.data_dir.glob("*.xlsb") if heat_id(p)}
        paths = cache_paths
    else:
        paths = sorted(p for p in args.data_dir.glob("*.xlsb") if heat_id(p))
        if len(paths) != 6:
            raise ValueError(f"Expected six 6C XLSB workbooks; found {[heat_id(p) for p in paths]}")

    t0 = time.time()
    data = {}
    with threadpool_limits(limits=1):
        for p in paths:
            h = p.stem if p.suffix == ".npz" else heat_id(p)
            print(f"Loading {h} ...", flush=True)
            d = load_heat_cache(p, source_by_heat.get(h)) if p.suffix == ".npz" else load_heat(p)
            d = fit_spectral_representation(d, args.seed)
            data[h] = d
            print(f"  rows={len(d['seq'])}, missing={d['missing_cells']}, sha256={d['sha256'][:12]}", flush=True)
    if args.target not in data:
        raise ValueError(f"Target {args.target} missing from input: {sorted(data)}")

    target = data[args.target]
    controls = {h: d for h, d in data.items() if h != args.target}
    n_target = len(target["seq"])
    if n_target != 775:
        print(f"WARNING: target has {n_target} rows rather than expected 775", flush=True)
    if not all(np.array_equal(target["wl"], d["wl"]) for d in data.values()):
        raise ValueError("Wavelength grids differ across 6C heats")

    audit = []
    for h, d in data.items():
        audit.append({
            "heat": h, "rows": len(d["seq"]), "spectral_channels": d["X"].shape[1],
            "missing_cells": d["missing_cells"],
            "sequence_contiguous": bool(np.array_equal(d["seq"], np.arange(1, len(d["seq"]) + 1))),
            "sha256": d["sha256"],
            "intensity_pca_variance_12pc": float(sum(d["pca_intensity_explained"])),
            "shape_pca_variance_12pc": float(sum(d["pca_shape_explained"])),
            "spectral_saturation_rate": float(np.mean(d["X"] == 65535)),
            "source_file": Path(d["path"]).name,
        })
    pd.DataFrame(audit).to_csv(args.out / "input_audit.csv", index=False)

    target_gas = np.column_stack([target["CO2"], target["CO"]])
    target_metrics = sequence_metrics(target["pc"], target["log_total"], target_gas, alpha=ALPHA)
    pd.DataFrame([{"heat": args.target, **target_metrics}]).to_csv(args.out / "target_observed_metrics.csv", index=False)

    rng = np.random.default_rng(args.seed)
    mechanisms = ["random", "regular", "bursty8", "bursty32"]
    sim_rows = []
    for h, d in controls.items():
        n = len(d["seq"]); m = min(n_target, n - 1)
        gas_full = np.column_stack([d["CO2"], d["CO"]])
        for mechanism in mechanisms:
            for rep in range(args.rep):
                idx_s = make_mask(n, m, mechanism, rng)
                # Shared mask: one retained row index for the full spectral/gas record.
                met = sequence_metrics(d["pc"][idx_s], d["log_total"][idx_s],
                                       gas_full[idx_s], include_cv=False)
                sim_rows.append({"heat": h, "mechanism": mechanism, "alignment": "shared",
                                 "rep": rep, "retention_rate": m/n,
                                 "median_abs_row_offset": 0.0, "p90_abs_row_offset": 0.0, **met})

                # Independent masks: spectral and gas streams are compressed separately,
                # then paired by their new row order as if the timestamps were discarded.
                idx_g = make_mask(n, m, mechanism, rng)
                offsets = np.abs(idx_s - idx_g)
                met = sequence_metrics(d["pc"][idx_s], d["log_total"][idx_s],
                                       gas_full[idx_g], include_cv=False)
                sim_rows.append({"heat": h, "mechanism": mechanism, "alignment": "independent",
                                 "rep": rep, "retention_rate": m/n,
                                 "median_abs_row_offset": float(np.median(offsets)),
                                 "p90_abs_row_offset": float(np.quantile(offsets, .9)), **met})

                # Negative control: shared row mask, but circularly shift the gas sequence
                # after compression to break exact pairing while preserving each marginal series.
                shift = int(rng.integers(max(10, m//8), max(11, m - max(10, m//8))))
                gas_shifted = np.roll(gas_full[idx_s], shift, axis=0)
                met = sequence_metrics(d["pc"][idx_s], d["log_total"][idx_s],
                                       gas_shifted, include_cv=False)
                sim_rows.append({"heat": h, "mechanism": mechanism, "alignment": "circular_shift",
                                 "rep": rep, "retention_rate": m/n,
                                 "median_abs_row_offset": np.nan,
                                 "p90_abs_row_offset": np.nan, "circular_shift_rows": shift, **met})
        print(f"Simulated {h}: {len(mechanisms) * args.rep} replicates per alignment", flush=True)

    sim = pd.DataFrame(sim_rows)
    sim.to_csv(args.out / "highdim_simulation_metrics.csv", index=False)

    # Mechanism separability is evaluated within each control heat, not by treating
    # Monte Carlo draws as independent real heats.
    primary = "rho_pc_dist_CO2"
    metric_names = ["rho_pc_dist_CO2", "rho_pc_dist_CO", "mean_abs_pc_rho_CO2", "mean_abs_pc_rho_CO",
                    "rho_log_brightness_CO2", "rho_log_brightness_CO"]
    auc_rows = []
    for (h, mechanism), g in sim[sim.alignment.isin(["shared", "independent"])].groupby(["heat", "mechanism"]):
        for metric in metric_names:
            x = g[g.alignment == "shared"][metric].dropna().to_numpy(float)
            y = g[g.alignment == "independent"][metric].dropna().to_numpy(float)
            if len(x) and len(y):
                labels = np.r_[np.ones(len(x)), np.zeros(len(y))]
                scores = np.r_[x, y]
                auc = float(roc_auc_score(labels, scores))
                auc_rows.append({"heat": h, "mechanism": mechanism, "metric": metric,
                                 "auc_shared_higher": auc, "auc_separability": max(auc, 1-auc),
                                 "shared_median": float(np.median(x)),
                                 "independent_median": float(np.median(y)),
                                 "median_difference": float(np.median(x)-np.median(y)),
                                 "n_shared": len(x), "n_independent": len(y)})
    auc_df = pd.DataFrame(auc_rows)
    auc_df.to_csv(args.out / "mechanism_discrimination.csv", index=False)
    auc_summary = (auc_df.groupby(["mechanism", "metric"], as_index=False)
                   .agg(median_auc_shared_higher=("auc_shared_higher", "median"),
                        median_auc_separability=("auc_separability", "median"),
                        min_auc_separability=("auc_separability", "min"),
                        max_auc_separability=("auc_separability", "max"),
                        control_heats_shared_higher=("auc_shared_higher", lambda x: int((x > .5).sum())),
                        n_control_heats=("heat", "nunique")))
    auc_summary.to_csv(args.out / "mechanism_discrimination_summary.csv", index=False)

    # Target percentile under each simulated mechanism, summarized within each heat first.
    comparison_rows = []
    for mechanism in mechanisms:
        for alignment in ["shared", "independent", "circular_shift"]:
            for metric in metric_names:
                per_heat = []
                for h, g in sim[(sim.mechanism == mechanism) & (sim.alignment == alignment)].groupby("heat"):
                    pct, med, spread = summarize_target(float(target_metrics[metric]), g[metric].to_numpy(float))
                    per_heat.append({"heat": h, "pct": pct, "median": med, "p90_p10_width": spread})
                ps = [x["pct"] for x in per_heat if np.isfinite(x["pct"])]
                comparison_rows.append({
                    "mechanism": mechanism, "alignment": alignment, "metric": metric,
                    "target_value": float(target_metrics[metric]),
                    "median_control_heat_target_percentile": float(np.median(ps)) if ps else np.nan,
                    "control_heat_target_percentile_min": float(np.min(ps)) if ps else np.nan,
                    "control_heat_target_percentile_max": float(np.max(ps)) if ps else np.nan,
                    "n_control_heats": len(ps),
                })
    comparison = pd.DataFrame(comparison_rows)
    comparison.to_csv(args.out / "target_mechanism_comparison.csv", index=False)

    # Regularization sensitivity on the observed target only. This checks whether
    # the no-incremental-skill result is an artifact of one Ridge penalty.
    alpha_rows = []
    alpha_values = [1.0, 10.0, 100.0]
    for alpha in alpha_values:
        tm = cv_skill_gain(target["pc"], target_gas, alpha=alpha)
        alpha_rows.append({"heat": args.target, "alignment": "observed", "alpha": alpha,
                           "skill_gain_mean": tm["skill_gain_mean"],
                           "skill_gain_CO2": tm["skill_gain_CO2"], "skill_gain_CO": tm["skill_gain_CO"]})
    pd.DataFrame(alpha_rows).to_csv(args.out / "alpha_sensitivity.csv", index=False)

    # Independent masks' order-statistic displacement is a useful sanity check.
    offset_summary = (sim[sim.alignment == "independent"]
                      .groupby(["heat", "mechanism"], as_index=False)
                      .agg(median_abs_row_offset=("median_abs_row_offset", "median"),
                           p90_abs_row_offset=("p90_abs_row_offset", "median")))
    offset_summary.to_csv(args.out / "independent_mask_offset_summary.csv", index=False)

    # Aggregate simulation distributions only after per-heat summaries.
    summary_rows = []
    for mechanism in mechanisms:
        for alignment in ["shared", "independent", "circular_shift"]:
            g = sim[(sim.mechanism == mechanism) & (sim.alignment == alignment)]
            for metric in metric_names:
                by_heat = g.groupby("heat")[metric].median().dropna()
                summary_rows.append({"mechanism": mechanism, "alignment": alignment, "metric": metric,
                                     "median_across_control_heat_medians": float(by_heat.median()) if len(by_heat) else np.nan,
                                     "control_heat_min": float(by_heat.min()) if len(by_heat) else np.nan,
                                     "control_heat_max": float(by_heat.max()) if len(by_heat) else np.nan,
                                     "n_control_heats": int(len(by_heat))})
    pd.DataFrame(summary_rows).to_csv(args.out / "alignment_summary.csv", index=False)

    summary = {
        "target": args.target, "target_rows": n_target, "spectral_channels": 2047,
        "pca_components_per_view": N_COMPONENTS, "pca_views": ["log_intensity", "row_normalized_shape"],
        "primary_metric": primary, "ridge_alpha": ALPHA, "cv_skill_metric": "skill_gain_mean (target only; not simulated)", "time_series_cv_splits": N_SPLITS,
        "cv_gap": CV_GAP, "replicates_per_control_heat_and_mask_mechanism": args.rep,
        "mask_mechanisms": mechanisms, "alignments": ["shared", "independent", "circular_shift"],
        "seed": args.seed, "control_heats": sorted(controls),
        "target_observed_metrics": target_metrics,
        "interpretation": "Exploratory row-alignment diagnostic. PCA is unsupervised and fit on each heat's full spectral sequence; gas labels are not used in PCA. Monte Carlo draws are conditional on five control heats and are not independent experimental units. No physical timestamp is inferred.",
        "runtime_seconds": round(time.time() - t0, 2),
    }
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)
    print("Wrote results to", args.out.resolve(), flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=1):
        main()
