#!/usr/bin/env python3
"""Extract one 6C XLSB workbook per short-lived process into a compact NPZ cache.

pyxlsb may retain native resources across repeated workbook reads in a long-lived
process, so the parent launches one worker process per workbook. Raw XLSB files
are read-only and never modified.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def hid(path: Path):
    m = re.search(r"Heat No\.\s*(6C\d+)\.xlsb$", path.name)
    return m.group(1) if m else None


def worker(path: Path, out_dir: Path):
    import numpy as np
    import pandas as pd
    frame = pd.read_excel(path, header=None, engine="pyxlsb")
    arr = frame.iloc[1:].to_numpy(dtype=np.float64, copy=True)
    if arr.shape[1] != 2051:
        raise ValueError(f"Unexpected shape {arr.shape} in {path.name}")
    wl = frame.iloc[0, 1:2048].to_numpy(dtype=np.float64, copy=True)
    h = hid(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    np.savez_compressed(
        out_dir / f"{h}.npz",
        seq=arr[:, 0].astype(np.int32),
        X=arr[:, 1:2048].astype(np.float32),
        O=arr[:, 2048], CO2=arr[:, 2049], CO=arr[:, 2050], wl=wl,
    )
    meta = {"heat": h, "source": str(path), "sha256": digest,
            "rows": int(len(arr)), "spectral_channels": 2047,
            "missing_cells": int(np.isnan(arr).sum())}
    (out_dir / f"{h}.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"cached {h}: {len(arr)} rows, sha256={digest}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--worker-file", type=Path)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    if args.worker_file:
        worker(args.worker_file, args.out_dir)
        return
    paths = sorted(p for p in args.data_dir.glob("*.xlsb") if hid(p))
    if len(paths) != 6:
        raise ValueError(f"Expected six 6C workbooks; found {[hid(p) for p in paths]}")
    for p in paths:
        h = hid(p)
        cache = args.out_dir / f"{h}.npz"
        meta = args.out_dir / f"{h}.json"
        if cache.exists() and meta.exists() and not args.force:
            print(f"skip existing cache {h}; pass --force to rebuild", flush=True)
            continue
        subprocess.run([sys.executable, str(Path(__file__).resolve()),
                        "--data-dir", str(args.data_dir), "--out-dir", str(args.out_dir),
                        "--worker-file", str(p), "--force"], check=True)

if __name__ == "__main__":
    main()
