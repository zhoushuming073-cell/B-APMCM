#!/usr/bin/env python3
"""Nested-LOHO study of stage-conditioned delay and regression for Q3.

All stage labels used for training are retrospective gas-derived labels from
training heats only. A held-out heat is routed using thresholds estimated from
the other nine heats (elapsed-time or cumulative-oxygen gating). Test gas is
used only for scoring. The script also audits whether spectral features add
information to online stage classification and tests warm-up sensitivity.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import io
import zipfile
from pathlib import Path

from pyxlsb import open_workbook

import numpy as np
import pandas as pd
from scipy.ndimage import median_filter, gaussian_filter1d
from scipy.signal import detrend
from scipy.stats import theilslopes
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    balanced_accuracy_score, f1_score, mean_absolute_error,
    mean_squared_error, r2_score,
)
from sklearn.metrics import confusion_matrix

DT = 0.5

def load_data_zip(path):
    heats = {}
    with zipfile.ZipFile(path) as archive:
        names = sorted(n for n in archive.namelist() if n.lower().endswith(".xlsb"))
        for name in names:
            with open_workbook(io.BytesIO(archive.read(name))) as wb:
                sheet_name = wb.sheets[0]
                with wb.get_sheet(sheet_name) as sheet:
                    rows = sheet.rows()
                    header = [cell.v for cell in next(rows)]
                    values = np.asarray([[cell.v for cell in row] for row in rows], dtype=float)
            if values.shape[1] != 2051:
                raise ValueError(f"Unexpected column count in {name}: {values.shape}")
            heat = str(sheet_name)
            heats[heat] = {
                "wavelength": np.asarray(header[1:2048], dtype=float),
                "spectrum": values[:, 1:2048],
                "oxygen": values[:, 2048],
                "gas": values[:, 2049:2051],
                "file": name,
            }
    if len(heats) != 10:
        raise ValueError(f"Expected ten heats, got {len(heats)}")
    return heats


def smooth_gas(gas):
    return median_filter(np.asarray(gas, dtype=float), size=(11, 1), mode="nearest")


def terminal_cutoff(data):
    gas = smooth_gas(data["gas"])
    t = np.arange(len(gas)) * DT
    peak = np.max(gas, axis=0)
    low = np.all(gas < peak[None, :] * 0.05, axis=1)
    run = int(10 / DT)
    start_search = max(int(120 / DT), int(0.5 * len(gas)))
    for i in range(start_search, len(gas) - run):
        if low[i:i + run].all():
            end = min(i + run, len(gas) - 1)
            if data["oxygen"][end] - data["oxygen"][i] > 1.0:
                return float(t[i])
    return None


def segment_cost_matrix(y, t, min_points=6):
    n, p = y.shape
    st = np.r_[0.0, np.cumsum(t)]
    st2 = np.r_[0.0, np.cumsum(t * t)]
    sy = np.vstack([np.zeros(p), np.cumsum(y, axis=0)])
    sty = np.vstack([np.zeros(p), np.cumsum(t[:, None] * y, axis=0)])
    sy2 = np.vstack([np.zeros(p), np.cumsum(y * y, axis=0)])
    cost = np.full((n + 1, n + 1), np.inf)
    for i in range(n):
        for j in range(i + min_points, n + 1):
            count = j - i
            sum_t, sum_t2 = st[j] - st[i], st2[j] - st2[i]
            det = count * sum_t2 - sum_t * sum_t
            sum_y, sum_ty, sum_y2 = sy[j] - sy[i], sty[j] - sty[i], sy2[j] - sy2[i]
            if det <= 1e-12:
                cost[i, j] = float(np.sum(sum_y2))
                continue
            b0 = (sum_t2 * sum_y - sum_t * sum_ty) / det
            b1 = (count * sum_ty - sum_t * sum_y) / det
            cost[i, j] = float(np.sum(sum_y2 - b0 * sum_y - b1 * sum_ty))
    return cost


def piecewise_linear_dp(y, t, segments=4, min_points=6):
    n = len(t)
    cost = segment_cost_matrix(y, t, min_points)
    dp = np.full((segments + 1, n + 1), np.inf)
    prev = np.full((segments + 1, n + 1), -1, dtype=int)
    dp[0, 0] = 0.0
    for k in range(1, segments + 1):
        for j in range(k * min_points, n + 1):
            starts = np.arange((k - 1) * min_points, j - min_points + 1)
            vals = dp[k - 1, starts] + cost[starts, j]
            if len(vals) and np.isfinite(vals).any():
                q = int(np.argmin(vals))
                dp[k, j], prev[k, j] = vals[q], starts[q]
    bounds, j = [n], n
    for k in range(segments, 0, -1):
        i = prev[k, j]
        if i < 0:
            raise RuntimeError("No valid piecewise segmentation")
        bounds.append(int(i))
        j = int(i)
    return bounds[::-1]


def stage_boundaries(heat, data):
    gas = smooth_gas(data["gas"])
    t = np.arange(len(gas)) * DT
    cut = terminal_cutoff(data)
    n = len(gas) if cut is None else max(1, int(cut / DT))
    gas, t = gas[:n], t[:n]
    co2, co = gas.T
    total = co2 + co
    share = np.clip(co2 / np.maximum(total, 0.1), 0.01, 0.99)
    y = np.column_stack([np.log(total + 0.2), np.log(share / (1 - share))])
    y = gaussian_filter1d(y, sigma=8 / DT, axis=0, mode="nearest")
    idx = np.arange(0, len(y), int(5 / DT))
    y, t5 = y[idx], t[idx]
    y = (y - y.mean(axis=0)) / np.maximum(y.std(axis=0), 1e-9)
    cuts = piecewise_linear_dp(y, t5, segments=4, min_points=6)
    return [float(t5[i]) for i in cuts[1:-1]], n

LAGS = np.arange(0, 61, 5, dtype=int)
PENALTIES = (0.01, 0.1, 1.0)
GASES = ("CO2", "CO")


def make_features(a):
    wl, x, oxygen = a["wavelength"], a["spectrum"], a["oxygen"]
    edges = np.linspace(345, 1015, 33)
    bands = np.stack([
        np.log1p(np.mean(x[:, (wl >= lo) & (wl < hi)], axis=1))
        for lo, hi in zip(edges[:-1], edges[1:])
    ], axis=1)
    if not np.isfinite(bands).all():
        raise ValueError("Non-finite spectral band features")
    i = np.arange(len(x))
    k = np.maximum(0, i - int(10 / DT))
    j = np.maximum(0, i - int(5 / DT))
    q = np.maximum(0, (oxygen - oxygen[k]) / np.maximum((i - k) * DT, DT))
    sat = np.mean(x >= 65535, axis=1)
    p = np.column_stack([
        i * DT / 600,
        (oxygen - oxygen[0]) / 3000,
        q / 5,
        (q - q[j]) / 5,
    ])
    brightness = bands.mean(axis=1)
    s = np.column_stack([bands, bands - bands[j], sat])
    return {
        "p": p, "s": s, "brightness": brightness,
        "gas": a["gas"], "oxygen": oxygen, "dt": DT,
    }


def get_stage_bounds(raw):
    out = {}
    for heat, a in raw.items():
        b, _ = stage_boundaries(heat, a)
        out[heat] = b
    return out


def stage_lag_profiles(a, boundaries):
    brightness = make_features(a)["brightness"]
    gas = smooth_gas(a["gas"])
    n = len(gas)
    cuts = [0] + [int(round(x / DT)) for x in boundaries] + [n]
    profiles = {}
    for stage, (i0, i1) in enumerate(zip(cuts[:-1], cuts[1:]), start=1):
        for gi, gas_name in enumerate(GASES):
            values = []
            for lag in LAGS:
                d = int(lag / DT)
                det = np.arange(max(i0 + d + 10, 11), min(i1, n), 2)
                src = det - d
                if len(det) < 20:
                    values.append(0.0)
                    continue
                dx = detrend(brightness[src] - brightness[src - 10])
                dy = detrend(gas[det, gi] - gas[det - 10, gi])
                corr = np.corrcoef(dx, dy)[0, 1] if dx.std() > 1e-12 and dy.std() > 1e-12 else 0.0
                values.append(abs(float(corr)) if np.isfinite(corr) else 0.0)
            profiles[(stage, gas_name)] = np.asarray(values)
    return profiles


def norm_dict(xs, train):
    mu = np.mean([xs[h].mean(0) for h in train], axis=0)
    sd = np.sqrt(np.mean([((xs[h] - mu) ** 2).mean(0) for h in train], axis=0))
    sd = np.where(sd > 1e-9, sd, 1.0)
    return {h: (x - mu) / sd for h, x in xs.items()}


def prepare_warmup(feat, warmup, lag_grid):
    data = {}
    for h, a in feat.items():
        idx = np.arange(int(warmup / a["dt"]), len(a["gas"]))
        k = int(5 / a["dt"])
        dy = a["gas"][idx] - a["gas"][idx - k]
        profile = []
        for lag in lag_grid:
            j = idx - int(lag / a["dt"])
            dx = a["brightness"][j] - a["brightness"][j - k]
            cor = [
                np.corrcoef(dx, dy[:, gi])[0, 1]
                if dx.std() > 1e-12 and dy[:, gi].std() > 1e-12 else 0.0
                for gi in range(2)
            ]
            profile.append(np.abs(cor))
        data[h] = {**a, "idx": idx, "profile": np.asarray(profile)}
    return data


def choose_lag(data, train, gi, lag_grid):
    profile = np.mean([data[h]["profile"][:, gi] for h in train], axis=0)
    return int(lag_grid[int(np.argmax(profile))])


def make_fold_design(data, train, test, gi, lead):
    hs = list(train) + [test]
    pp, ss, yy = {}, {}, {}
    for h in hs:
        a = data[h]
        j = a["idx"] - int(lead / a["dt"])
        pp[h] = a["p"][j]
        ss[h] = a["s"][j]
        yy[h] = a["gas"][a["idx"], gi]
    p = norm_dict(pp, train)
    s = norm_dict(ss, train)
    cov = np.mean([s[h].T @ s[h] / len(s[h]) for h in train], axis=0)
    _, vec = np.linalg.eigh(cov)
    z = {h: s[h] @ vec[:, -8:] for h in hs}
    p2 = {
        h: np.column_stack([
            p[h], *[p[h][:, i] * p[h][:, j] for i in range(4) for j in range(i, 4)]
        ]) for h in hs
    }
    design = {h: np.column_stack([p2[h], z[h]]) for h in hs}
    design = norm_dict(design, train)
    design = {h: np.column_stack([np.ones(len(design[h])), design[h]]) for h in hs}
    return design, yy


def ridge_fit_predict(design, y, train, test, penalty):
    aa, bb = [], []
    for h in train:
        x, target = design[h], y[h]
        aa.append(x.T @ x / len(target))
        bb.append(x.T @ target / len(target))
    a, b = np.mean(aa, axis=0), np.mean(bb, axis=0)
    reg = np.eye(len(b)) * penalty
    reg[0, 0] = 0
    return design[test] @ np.linalg.solve(a + reg, b)


def run_warmup(feat, warmup, lag_grid, stage_bounds_map):
    data = prepare_warmup(feat, warmup, lag_grid)
    heats = sorted(data)
    fold_rows, pred_rows, lag_rows = [], [], []
    for gi, gas in enumerate(GASES):
        for test in heats:
            train = [h for h in heats if h != test]
            inner = {p: [] for p in PENALTIES}
            for val in train:
                tr = [h for h in train if h != val]
                lead = choose_lag(data, tr, gi, lag_grid)
                design, y = make_fold_design(data, tr, val, gi, lead)
                for pen in PENALTIES:
                    pred = ridge_fit_predict(design, y, tr, val, pen)
                    inner[pen].append(mean_absolute_error(y[val], np.maximum(0, pred)))
            best = min(PENALTIES, key=lambda p: np.mean(inner[p]))
            lead = choose_lag(data, train, gi, lag_grid)
            design, y = make_fold_design(data, train, test, gi, lead)
            pred = ridge_fit_predict(design, y, train, test, best)
            target, fitted = y[test], np.maximum(0, pred)
            times = data[test]["idx"] * DT
            stages = np.digitize(times, stage_bounds_map[test]) + 1
            fold_rows.append({
                "warmup_s": warmup, "lag_max_s": int(np.max(lag_grid)),
                "gas": gas, "heat": test, "lead_s": lead, "penalty": best,
                "n": len(target), "mae": mean_absolute_error(target, fitted),
                "rmse": mean_squared_error(target, fitted) ** 0.5,
                "r2": r2_score(target, fitted),
            })
            lag_rows.append({"warmup_s": warmup, "gas": gas, "heat": test, "lead_s": lead})
            for t, y0, yh, st in zip(times, target, fitted, stages):
                pred_rows.append((warmup, gas, test, t, y0, yh, int(st)))
    return (
        pd.DataFrame(fold_rows),
        pd.DataFrame(pred_rows, columns=[
            "warmup_s", "gas", "heat", "detector_s", "observed", "predicted", "stage"
        ]),
        pd.DataFrame(lag_rows),
    )


def transform_stage_features(data, train, test, variant):
    hs = list(train) + [test]
    p = {h: data[h]["p"] for h in hs}
    s = {h: data[h]["s"] for h in hs}
    if variant == "clock":
        x = {h: p[h][:, :1] for h in hs}
    elif variant == "process":
        x = norm_dict(p, train)
    elif variant == "process_no_clock":
        x = {h: p[h][:, 1:] for h in hs}
    elif variant == "spectral":
        sn = norm_dict(s, train)
        cov = np.mean([sn[h].T @ sn[h] / len(sn[h]) for h in train], axis=0)
        _, vec = np.linalg.eigh(cov)
        x = {h: sn[h] @ vec[:, -8:] for h in hs}
    elif variant in ("fusion", "process_no_clock_fusion"):
        pn, sn = norm_dict(p, train), norm_dict(s, train)
        cov = np.mean([sn[h].T @ sn[h] / len(sn[h]) for h in train], axis=0)
        _, vec = np.linalg.eigh(cov)
        z = {h: sn[h] @ vec[:, -8:] for h in hs}
        if variant == "fusion":
            x = {h: np.column_stack([pn[h], z[h]]) for h in hs}
        else:
            x = {h: np.column_stack([pn[h][:, 1:], z[h]]) for h in hs}
    else:
        raise ValueError(variant)
    return norm_dict(x, train)


def fit_stage_classifier(x, data, train, c):
    xx = np.concatenate([x[h] for h in train], axis=0)
    yy = np.concatenate([data[h]["label"] for h in train])
    weights = np.concatenate([
        np.full(len(data[h]["label"]), 1 / len(data[h]["label"])) for h in train
    ])
    clf = LogisticRegression(C=c, class_weight="balanced", max_iter=2000, solver="lbfgs")
    clf.fit(xx, yy, sample_weight=weights)
    return clf


def run_stage_classifier(feat, stage_bounds_map):
    data = {}
    for h, a in feat.items():
        idx = np.arange(0, len(a["gas"]), 10)  # one sample every 5 seconds
        times = idx * DT
        labels = np.digitize(times, stage_bounds_map[h]) + 1
        data[h] = {"p": a["p"][idx], "s": a["s"][idx], "time": times, "label": labels}
    variants = ("clock", "process", "process_no_clock", "spectral", "fusion", "process_no_clock_fusion")
    c_grid = (0.01, 0.1, 1.0, 10.0)
    heats = sorted(data)
    rows, pred_rows, conf_rows = [], [], []
    for test in heats:
        train = [h for h in heats if h != test]
        for variant in variants:
            inner = {c: [] for c in c_grid}
            for val in train:
                tr = [h for h in train if h != val]
                x = transform_stage_features(data, tr, val, variant)
                for c in c_grid:
                    clf = fit_stage_classifier(x, data, tr, c)
                    yp = clf.predict(x[val])
                    inner[c].append(f1_score(
                        data[val]["label"], yp, labels=[1, 2, 3, 4],
                        average="macro", zero_division=0,
                    ))
            best = max(c_grid, key=lambda c: np.mean(inner[c]))
            x = transform_stage_features(data, train, test, variant)
            clf = fit_stage_classifier(x, data, train, best)
            yp = clf.predict(x[test])
            yt = data[test]["label"]
            rows.append({
                "heat": test, "model": variant, "C": best,
                "macro_f1": f1_score(yt, yp, labels=[1, 2, 3, 4], average="macro", zero_division=0),
                "balanced_accuracy": balanced_accuracy_score(yt, yp),
                "accuracy": float(np.mean(yp == yt)),
            })
            cm = confusion_matrix(yt, yp, labels=[1, 2, 3, 4])
            for i in range(4):
                for j in range(4):
                    conf_rows.append((test, variant, i + 1, j + 1, int(cm[i, j])))
            for t, y0, yh in zip(data[test]["time"], yt, yp):
                pred_rows.append((test, variant, t, int(y0), int(yh)))
    return (
        pd.DataFrame(rows),
        pd.DataFrame(pred_rows, columns=["heat", "model", "time_s", "true_stage", "pred_stage"]),
        pd.DataFrame(conf_rows, columns=["heat", "model", "true_stage", "pred_stage", "count"]),
    )


def run_boundary_thresholds(raw, stage_bounds_map):
    rows = []
    heats = sorted(raw)
    for test in heats:
        train = [h for h in heats if h != test]
        time_thresholds = [
            float(np.median([stage_bounds_map[h][j] for h in train])) for j in range(3)
        ]
        oxygen_thresholds = []
        for j in range(3):
            vals = []
            for h in train:
                idx = int(round(stage_bounds_map[h][j] / DT))
                vals.append(raw[h]["oxygen"][idx])
            oxygen_thresholds.append(float(np.median(vals)))
        for gate, thresholds, values in (
            ("elapsed_time", time_thresholds, np.arange(len(raw[test]["gas"])) * DT),
            ("cumulative_oxygen", oxygen_thresholds, raw[test]["oxygen"]),
        ):
            yt = np.digitize(np.arange(len(values)) * DT, stage_bounds_map[test]) + 1
            yp = np.digitize(values, thresholds) + 1
            rows.append({
                "heat": test, "gating": gate,
                "macro_f1": f1_score(yt, yp, labels=[1, 2, 3, 4], average="macro", zero_division=0),
                "balanced_accuracy": balanced_accuracy_score(yt, yp),
                "accuracy": float(np.mean(yt == yp)),
                "threshold1": thresholds[0], "threshold2": thresholds[1], "threshold3": thresholds[2],
            })
    return pd.DataFrame(rows)


def stage_lags_from_train(train, profiles, gas_idx, lag_grid):
    gas = GASES[gas_idx]
    out = {}
    for stage in range(1, 5):
        arr = np.stack([profiles[h][(stage, gas)] for h in train])
        out[stage] = int(lag_grid[int(np.argmax(arr.mean(axis=0)))])
    return out


def median_time_boundaries(train, stage_bounds_map):
    return [float(np.median([stage_bounds_map[h][j] for h in train])) for j in range(3)]


def median_oxygen_boundaries(train, raw, stage_bounds_map):
    out = []
    for j in range(3):
        vals = []
        for h in train:
            idx = int(round(stage_bounds_map[h][j] / DT))
            vals.append(raw[h]["oxygen"][idx])
        out.append(float(np.median(vals)))
    return out


def aligned_rows(h, gas_idx, stage_lags, labels, feat):
    a = feat[h]
    idx = np.arange(len(a["gas"]))
    rows = []
    for stage in range(1, 5):
        lag = stage_lags[stage]
        src = idx - int(lag / DT)
        mask = (labels == stage) & (src >= 0)
        ti, si = idx[mask], src[mask].astype(int)
        rows.append((
            a["p"][si], a["s"][si], a["gas"][ti, gas_idx],
            np.full(len(ti), stage, dtype=int), ti * DT, si * DT,
        ))
    return tuple(np.concatenate([r[j] for r in rows], axis=0) for j in range(6))


def global_rows(h, gas_idx, lead, feat):
    a = feat[h]
    idx = np.arange(len(a["gas"]))
    src = idx - int(lead / DT)
    mask = src >= 0
    idx, src = idx[mask], src[mask]
    times = idx * DT
    return a["p"][src], a["s"][src], a["gas"][idx, gas_idx], np.zeros(len(idx), dtype=int), times, times - lead


def make_aligned_design(train_rows, test_rows, train):
    hs = list(train) + ["__test__"]
    pp = {h: train_rows[h][0] if h != "__test__" else test_rows[0] for h in hs}
    ss = {h: train_rows[h][1] if h != "__test__" else test_rows[1] for h in hs}
    p, s = norm_dict(pp, train), norm_dict(ss, train)
    cov = np.mean([s[h].T @ s[h] / len(s[h]) for h in train], axis=0)
    _, vec = np.linalg.eigh(cov)
    z = {h: s[h] @ vec[:, -8:] for h in hs}
    p2 = {
        h: np.column_stack([
            p[h], *[p[h][:, i] * p[h][:, j] for i in range(4) for j in range(i, 4)]
        ]) for h in hs
    }
    design = {h: np.column_stack([p2[h], z[h]]) for h in hs}
    design = norm_dict(design, train)
    design = {h: np.column_stack([np.ones(len(design[h])), design[h]]) for h in hs}
    return {h: design[h] for h in train}, design["__test__"]


def fit_global_ridge(x_train, y_train, train, penalty):
    aa, bb = [], []
    for h in train:
        x, y = x_train[h], y_train[h]
        aa.append(x.T @ x / len(y))
        bb.append(x.T @ y / len(y))
    a, b = np.mean(aa, axis=0), np.mean(bb, axis=0)
    reg = np.eye(len(b)) * penalty
    reg[0, 0] = 0
    return np.linalg.solve(a + reg, b)


def fit_stage_ridges(x_train, y_train, stage_train, train, penalty):
    coefs = {}
    for stage in range(1, 5):
        aa, bb = [], []
        for h in train:
            mask = stage_train[h] == stage
            if mask.sum() == 0:
                continue
            x, y = x_train[h][mask], y_train[h][mask]
            aa.append(x.T @ x / len(y))
            bb.append(x.T @ y / len(y))
        a, b = np.mean(aa, axis=0), np.mean(bb, axis=0)
        reg = np.eye(len(b)) * penalty
        reg[0, 0] = 0
        coefs[stage] = np.linalg.solve(a + reg, b)
    return coefs


def predict_stage_models(train, test, gas_idx, penalty, gating, raw, feat, stage_bounds_map, profiles, prep65, lag_grid):
    stage_lags = stage_lags_from_train(train, profiles, gas_idx, lag_grid)
    train_rows = {}
    for h in train:
        times = np.arange(len(feat[h]["gas"])) * DT
        labels = np.digitize(times, stage_bounds_map[h]) + 1
        train_rows[h] = aligned_rows(h, gas_idx, stage_lags, labels, feat)
    if gating == "clock":
        gate_values = median_time_boundaries(train, stage_bounds_map)
        test_times = np.arange(len(feat[test]["gas"])) * DT
        test_labels = np.digitize(test_times, gate_values) + 1
    elif gating == "oxygen":
        gate_values = median_oxygen_boundaries(train, raw, stage_bounds_map)
        test_labels = np.digitize(raw[test]["oxygen"], gate_values) + 1
    else:
        raise ValueError(gating)
    test_rows = aligned_rows(test, gas_idx, stage_lags, test_labels, feat)
    x_train, x_test = make_aligned_design(train_rows, test_rows, train)
    y_train = {h: train_rows[h][2] for h in train}
    y_test, stage_test = test_rows[2], test_rows[3]
    coef_lag = fit_global_ridge(x_train, y_train, train, penalty)
    pred_lag = x_test @ coef_lag
    stage_train = {h: train_rows[h][3] for h in train}
    coefs = fit_stage_ridges(x_train, y_train, stage_train, train, penalty)
    pred_expert = np.asarray([x_test[i] @ coefs[int(st)] for i, st in enumerate(stage_test)])

    global_lead = choose_lag(prep65, train, gas_idx, lag_grid)
    global_train = {h: global_rows(h, gas_idx, global_lead, feat) for h in train}
    global_test = global_rows(test, gas_idx, global_lead, feat)
    xg_train, xg_test = make_aligned_design(global_train, global_test, train)
    yg_train = {h: global_train[h][2] for h in train}
    coef_global = fit_global_ridge(xg_train, yg_train, train, penalty)
    pred_global = xg_test @ coef_global
    return {
        "stage_lags": stage_lags, "gate_values": gate_values,
        "stage_rows": (test_rows[4], test_rows[5], y_test, stage_test, pred_lag, pred_expert),
        "global": (global_test[4], global_test[2], pred_global, global_lead),
    }


def run_stage_prediction(raw, feat, stage_bounds_map, profiles, gating, gas_idx, prep65, lag_grid=LAGS):
    heats = sorted(feat)
    fold_rows, pred_rows, lag_rows = [], [], []
    gas = GASES[gas_idx]
    for test in heats:
        train = [h for h in heats if h != test]
        inner = {m: {p: [] for p in PENALTIES} for m in ("global", "stage_lag", "stage_expert")}
        for val in train:
            tr = [h for h in train if h != val]
            for pen in PENALTIES:
                out = predict_stage_models(
                    tr, val, gas_idx, pen, gating, raw, feat, stage_bounds_map, profiles,
                    prep65, lag_grid,
                )
                tg, yg, pg, _ = out["global"]
                tt, _, yt, _, pl, pe = out["stage_rows"]
                common = np.intersect1d(tt, tg)
                ms, mg = np.isin(tt, common), np.isin(tg, common)
                inner["global"][pen].append(mean_absolute_error(yg[mg], np.maximum(0, pg[mg])))
                inner["stage_lag"][pen].append(mean_absolute_error(yt[ms], np.maximum(0, pl[ms])))
                inner["stage_expert"][pen].append(mean_absolute_error(yt[ms], np.maximum(0, pe[ms])))
        best = {m: min(PENALTIES, key=lambda p: np.mean(inner[m][p])) for m in inner}
        outs = {
            p: predict_stage_models(
                train, test, gas_idx, p, gating, raw, feat, stage_bounds_map, profiles,
                prep65, lag_grid,
            ) for p in set(best.values())
        }
        out_lag, out_exp, out_global = outs[best["stage_lag"]], outs[best["stage_expert"]], outs[best["global"]]
        tt, tp, yt, _, pl, _ = out_lag["stage_rows"]
        _, _, _, _, _, pe = out_exp["stage_rows"]
        tg, yg, pg, global_lead = out_global["global"]
        common = np.intersect1d(tt, tg)
        ms, mg = np.isin(tt, common), np.isin(tg, common)
        actual_stage_s = np.digitize(tt, stage_bounds_map[test]) + 1
        actual_stage_g = np.digitize(tg, stage_bounds_map[test]) + 1

        for name, pred, times, target, stages, mask, pen, lead in (
            ("global", pg, tg, yg, actual_stage_g, mg, best["global"], global_lead),
            ("stage_lag", pl, tt, yt, actual_stage_s, ms, best["stage_lag"], str(out_lag["stage_lags"])),
            ("stage_expert", pe, tt, yt, actual_stage_s, ms, best["stage_expert"], str(out_exp["stage_lags"])),
        ):
            pred_valid, target_valid = np.maximum(0, pred[mask]), target[mask]
            fold_rows.append({
                "gas": gas, "gating": gating, "heat": test, "model": name, "penalty": pen,
                "mae": mean_absolute_error(target_valid, pred_valid),
                "rmse": mean_squared_error(target_valid, pred_valid) ** 0.5,
                "r2": r2_score(target_valid, pred_valid), "n": len(target_valid),
                "lead_or_stage_lags": str(lead),
            })

        for name, pred, target, pen, lead in (
            ("global_full", pg, yg, best["global"], global_lead),
            ("stage_lag_full", pl, yt, best["stage_lag"], str(out_lag["stage_lags"])),
            ("stage_expert_full", pe, yt, best["stage_expert"], str(out_exp["stage_lags"])),
        ):
            pv = np.maximum(0, pred)
            fold_rows.append({
                "gas": gas, "gating": gating, "heat": test, "model": name, "penalty": pen,
                "mae": mean_absolute_error(target, pv),
                "rmse": mean_squared_error(target, pv) ** 0.5,
                "r2": r2_score(target, pv), "n": len(target),
                "lead_or_stage_lags": str(lead),
            })

        for name, pred, times, target, stages, publish in (
            ("global", np.maximum(0, pg), tg, yg, actual_stage_g, tg - global_lead),
            ("stage_lag", np.maximum(0, pl), tt, yt, actual_stage_s, tp),
            ("stage_expert", np.maximum(0, pe), tt, yt, actual_stage_s, tp),
        ):
            for t, pub, y0, yh, st in zip(times, publish, target, pred, stages):
                pred_rows.append((gas, gating, test, name, t, pub, y0, yh, int(st)))

        lag_rows.append({
            "gas": gas, "gating": gating, "heat": test, "global_lag": global_lead,
            **{f"stage{j}_lag": v for j, v in out_lag["stage_lags"].items()},
            **{f"gate{j}": v for j, v in enumerate(out_lag["gate_values"], 1)},
            "common_n": len(common), "stage_only_n": len(tt) - len(common),
        })
        print(f"stage prediction {gas} {gating}: {test}", flush=True)

    return (
        pd.DataFrame(fold_rows),
        pd.DataFrame(pred_rows, columns=[
            "gas", "gating", "heat", "model", "detector_s", "publish_s",
            "observed", "predicted", "actual_stage",
        ]),
        pd.DataFrame(lag_rows),
    )


def run_boundary_shift(raw, feat, stage_bounds_map, profiles, gas_idx, fixed_penalty, prep65, shifts=(-10, 0, 10)):
    gas = GASES[gas_idx]
    heats = sorted(feat)
    rows = []
    for test in heats:
        train = [h for h in heats if h != test]
        stage_lags = stage_lags_from_train(train, profiles, gas_idx, LAGS)
        base_bounds = median_time_boundaries(train, stage_bounds_map)
        train_rows = {}
        for h in train:
            times = np.arange(len(feat[h]["gas"])) * DT
            labels = np.digitize(times, stage_bounds_map[h]) + 1
            train_rows[h] = aligned_rows(h, gas_idx, stage_lags, labels, feat)
        for shift in shifts:
            gate = [x + shift for x in base_bounds]
            test_times = np.arange(len(feat[test]["gas"])) * DT
            labels = np.digitize(test_times, gate) + 1
            test_rows = aligned_rows(test, gas_idx, stage_lags, labels, feat)
            x_train, x_test = make_aligned_design(train_rows, test_rows, train)
            y_train = {h: train_rows[h][2] for h in train}
            st_train = {h: train_rows[h][3] for h in train}
            coefs = fit_stage_ridges(x_train, y_train, st_train, train, fixed_penalty)
            pe = np.maximum(0, np.asarray([x_test[i] @ coefs[int(st)] for i, st in enumerate(test_rows[3])]))

            global_lead = choose_lag(prep65, train, gas_idx, LAGS)
            gtrain = {h: global_rows(h, gas_idx, global_lead, feat) for h in train}
            gtest = global_rows(test, gas_idx, global_lead, feat)
            gx_train, gx_test = make_aligned_design(gtrain, gtest, train)
            gy_train = {h: gtrain[h][2] for h in train}
            gc = fit_global_ridge(gx_train, gy_train, train, fixed_penalty)
            pg = np.maximum(0, gx_test @ gc)
            common = np.intersect1d(test_rows[4], gtest[4])
            ms, mg = np.isin(test_rows[4], common), np.isin(gtest[4], common)
            for model, target, pred, mask in (
                ("global", gtest[2], pg, mg),
                ("stage_expert", test_rows[2], pe, ms),
            ):
                rows.append({
                    "gas": gas, "heat": test, "shift_s": shift, "model": model,
                    "fixed_penalty": fixed_penalty,
                    "mae": mean_absolute_error(target[mask], pred[mask]),
                    "r2": r2_score(target[mask], pred[mask]), "n": len(common),
                })
        print(f"boundary shift {gas}: {test}", flush=True)
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-zip", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    digest = hashlib.sha256(args.data_zip.read_bytes()).hexdigest()
    raw = load_data_zip(args.data_zip)
    feat = {h: make_features(a) for h, a in raw.items()}
    stage_bounds_map = get_stage_bounds(raw)
    profiles = {h: stage_lag_profiles(raw[h], stage_bounds_map[h]) for h in raw}
    prep65 = prepare_warmup(feat, 65, LAGS)

    # 1) Warm-up sensitivity: W35 uses a restricted 0-30 s lead grid;
    # W65/90/120 use the same 0-60 s grid.
    warmup_folds, warmup_preds, warmup_lags = [], [], []
    for warmup, grid in ((35, np.arange(0, 31, 5)), (65, LAGS), (90, LAGS), (120, LAGS)):
        f, p, l = run_warmup(feat, warmup, grid, stage_bounds_map)
        warmup_folds.append(f)
        warmup_preds.append(p)
        warmup_lags.append(l)
    warmup_folds = pd.concat(warmup_folds, ignore_index=True)
    warmup_preds = pd.concat(warmup_preds, ignore_index=True)
    warmup_lags = pd.concat(warmup_lags, ignore_index=True)
    warmup_folds.to_csv(args.output_dir / "warmup_fold_metrics.csv", index=False)
    warmup_lags.to_csv(args.output_dir / "warmup_lag_selections.csv", index=False)
    warmup_preds.to_csv(args.output_dir / "warmup_predictions.csv.gz", index=False, compression="gzip")
    warmup_summary = []
    for (w, gas), group in warmup_preds.groupby(["warmup_s", "gas"]):
        for domain, sub in (("full_valid", group), ("common_ge120s", group[group.detector_s >= 120])):
            by_heat = []
            for heat, g in sub.groupby("heat"):
                if len(g) < 2:
                    continue
                by_heat.append({
                    "mae": mean_absolute_error(g.observed, g.predicted),
                    "rmse": mean_squared_error(g.observed, g.predicted) ** 0.5,
                    "r2": r2_score(g.observed, g.predicted),
                    "n": len(g),
                })
            if by_heat:
                d = pd.DataFrame(by_heat).mean()
                warmup_summary.append({
                    "warmup_s": w, "gas": gas, "domain": domain,
                    "mae": d.mae, "rmse": d.rmse, "r2": d.r2, "n_per_heat": d.n,
                })
    pd.DataFrame(warmup_summary).to_csv(args.output_dir / "warmup_sensitivity.csv", index=False)

    # 2) Online stage-classification audit and train-only boundary baselines.
    class_folds, class_preds, class_conf = run_stage_classifier(feat, stage_bounds_map)
    class_folds.to_csv(args.output_dir / "stage_classifier_folds.csv", index=False)
    class_preds.to_csv(args.output_dir / "stage_classifier_predictions.csv", index=False)
    class_conf.to_csv(args.output_dir / "stage_classifier_confusion.csv", index=False)
    class_summary = class_folds.groupby("model").agg(
        macro_f1=("macro_f1", "mean"), macro_f1_sd=("macro_f1", "std"),
        balanced_accuracy=("balanced_accuracy", "mean"),
        accuracy=("accuracy", "mean"),
    ).reset_index()
    class_summary.to_csv(args.output_dir / "stage_classifier_summary.csv", index=False)
    boundary_folds = run_boundary_thresholds(raw, stage_bounds_map)
    boundary_folds.to_csv(args.output_dir / "stage_boundary_folds.csv", index=False)

    # 3) Stage-conditioned lag and stage-expert prediction, clock and oxygen gates.
    all_stage_folds, all_stage_preds, all_stage_lags = [], [], []
    for gating in ("clock", "oxygen"):
        for gi in range(2):
            f, p, l = run_stage_prediction(
                raw, feat, stage_bounds_map, profiles, gating, gi, prep65, LAGS
            )
            all_stage_folds.append(f)
            all_stage_preds.append(p)
            all_stage_lags.append(l)
    stage_folds = pd.concat(all_stage_folds, ignore_index=True)
    stage_preds = pd.concat(all_stage_preds, ignore_index=True)
    stage_lags = pd.concat(all_stage_lags, ignore_index=True)
    stage_folds.to_csv(args.output_dir / "stage_lag_fold_metrics.csv", index=False)
    stage_lags.to_csv(args.output_dir / "stage_lag_selections.csv", index=False)
    stage_preds.to_csv(args.output_dir / "stage_lag_predictions.csv.gz", index=False, compression="gzip")
    stage_summary = stage_folds.groupby(["gas", "gating", "model"]).agg(
        mae=("mae", "mean"), rmse=("rmse", "mean"), r2=("r2", "mean"),
        n_per_heat=("n", "mean"),
    ).reset_index()
    stage_summary.to_csv(args.output_dir / "stage_lag_summary.csv", index=False)

    # Stage-wise MAE on the common prediction support for global vs stage experts.
    stagewise = []
    for (gas, gating), d in stage_preds.groupby(["gas", "gating"]):
        for heat in sorted(d.heat.unique()):
            sub = d[d.heat == heat]
            g = sub[sub.model == "global"]
            e = sub[sub.model == "stage_expert"]
            common = np.intersect1d(g.detector_s, e.detector_s)
            g, e = g[g.detector_s.isin(common)], e[e.detector_s.isin(common)]
            for stage in range(1, 5):
                for model, z in (("global", g), ("stage_expert", e)):
                    z = z[z.actual_stage == stage]
                    if len(z) < 2:
                        continue
                    stagewise.append({
                        "gas": gas, "gating": gating, "heat": heat, "stage": stage, "model": model,
                        "mae": mean_absolute_error(z.observed, z.predicted), "n": len(z),
                    })
    pd.DataFrame(stagewise).to_csv(args.output_dir / "stagewise_mae.csv", index=False)

    # 4) Boundary perturbation sensitivity using modal nested penalty.
    shift_rows = []
    for gi, gas in enumerate(GASES):
        q = stage_folds[
            (stage_folds.gas == gas) & (stage_folds.gating == "clock") &
            (stage_folds.model == "stage_expert")
        ]
        fixed_penalty = float(q.penalty.mode().iloc[0])
        shift_rows.append(run_boundary_shift(
            raw, feat, stage_bounds_map, profiles, gi, fixed_penalty, prep65
        ))
    shift_df = pd.concat(shift_rows, ignore_index=True)
    shift_df.to_csv(args.output_dir / "boundary_shift_sensitivity.csv", index=False)

    # 5) Tail-slope diagnostic: smooth only along time, never across gas channels.
    tail_rows = []
    clock_preds = stage_preds[stage_preds.gating == "clock"]
    for gas in GASES:
        gi = GASES.index(gas)
        dg = clock_preds[clock_preds.gas == gas]
        for heat in sorted(raw):
            end = terminal_cutoff(raw[heat])
            if end is None:
                end = (len(raw[heat]["gas"]) - 1) * DT
            start = end - 60
            obs_smooth = smooth_gas(raw[heat]["gas"])[:, gi]
            for model in ("global", "stage_lag", "stage_expert"):
                z = dg[(dg.heat == heat) & (dg.model == model)].sort_values("detector_s")
                times = z.detector_s.to_numpy()
                pred = z.predicted.to_numpy()
                pred_smooth = median_filter(pred, size=11, mode="nearest")
                mask = (times >= start) & (times <= end)
                if mask.sum() < 10:
                    continue
                obs = obs_smooth[np.round(times[mask] / DT).astype(int)]
                obs_slope = float(theilslopes(obs, times[mask]).slope * 60)
                pred_slope = float(theilslopes(pred_smooth[mask], times[mask]).slope * 60)
                tail_rows.append({
                    "gas": gas, "heat": heat, "model": model, "tail_end_s": end,
                    "n": int(mask.sum()), "observed_slope_per_min": obs_slope,
                    "predicted_slope_per_min": pred_slope,
                    "sign_match": bool(np.sign(obs_slope) == np.sign(pred_slope)),
                })
    pd.DataFrame(tail_rows).to_csv(args.output_dir / "tail_slope_diagnostics.csv", index=False)

    # Compact stage-lag profile summary.
    profile_rows = []
    for stage in range(1, 5):
        for gas in GASES:
            arr = np.stack([profiles[h][(stage, gas)] for h in sorted(profiles)])
            mean_profile = arr.mean(axis=0)
            profile_rows.append({
                "stage": stage, "gas": gas,
                "mean_profile_best_lag_s": int(LAGS[int(np.argmax(mean_profile))]),
                "mean_abs_corr_at_best": float(mean_profile.max()),
            })
    pd.DataFrame(profile_rows).to_csv(args.output_dir / "stage_lag_profile_summary.csv", index=False)

    manifest = {
        "data_zip": str(args.data_zip),
        "sha256": digest,
        "heats": len(raw),
        "rows": int(sum(len(a["gas"]) for a in raw.values())),
        "wavelength_channels": 2047,
        "dt_s": DT,
        "stage_boundaries_s": {h: stage_bounds_map[h] for h in sorted(stage_bounds_map)},
        "outputs": sorted(p.name for p in args.output_dir.iterdir() if p.is_file()),
        "notes": [
            "H0 only; 0.5 s per row for all ten heats.",
            "Four gas-defined stages are retrospective diagnostic pseudo-labels.",
            "Test stage routing uses training-only median time or oxygen thresholds.",
            "All model comparisons use nested leave-one-heat-out folds.",
            "The stage-4 lag profile is weak and must not be interpreted as physical transport time.",
        ],
    }
    (args.output_dir / "run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
