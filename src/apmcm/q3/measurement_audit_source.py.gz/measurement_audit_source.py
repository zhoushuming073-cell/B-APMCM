#!/usr/bin/env python3
"""Audit Q3 gas-channel semantics and quantify terminal composition changes.

The script deliberately separates measured gas-channel values from actual gas
molar/volume flow. It tests the m3/s interpretation as a conditional
stoichiometric feasibility check; it does not assume that interpretation is
correct.
"""
from __future__ import annotations
import argparse, hashlib, io, json, re, zipfile, tempfile
from pathlib import Path
import numpy as np
import pandas as pd
from pyxlsb import open_workbook
from scipy.ndimage import median_filter
from scipy.stats import theilslopes

DT = 0.5
EXPECTED_SHA256 = "cb662ce5ea17c247d0733ec8a4245fec37abf82d823a0ddc08597b300d95a727"


def _read_one_workbook(workbook_path: Path, out_path: Path):
    with open_workbook(workbook_path) as wb:
        with wb.get_sheet(wb.sheets[0]) as sheet:
            rows = sheet.rows()
            header = [c.v for c in next(rows)]
            if len(header) != 2051 or tuple(header[-2:]) not in {
                ("CO2浓度", "CO浓度"),
                ("CO₂ concentration", "CO concentration"),
            }:
                raise ValueError(f"Unexpected gas headers: {header[-3:]}")
            oxygen_header = str(header[-3])
            oxygen, gas = [], []
            for row in rows:
                oxygen.append(row[-3].v)
                gas.append([row[-2].v, row[-1].v])
    oxygen = np.asarray(oxygen, dtype=float)
    gas = np.asarray(gas, dtype=float)
    if gas.ndim != 2 or gas.shape[1] != 2 or not np.isfinite(gas).all() or not np.isfinite(oxygen).all():
        raise ValueError(f"Non-finite or malformed measurements in {workbook_path.name}")
    np.savez_compressed(out_path, oxygen=oxygen, gas=gas, oxygen_header=oxygen_header)


def read_heats(path: Path):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != EXPECTED_SHA256:
        raise ValueError(f"Unexpected Data.zip SHA256: {digest}")
    heats = {}
    with zipfile.ZipFile(path) as archive, tempfile.TemporaryDirectory() as tmp:
        names = sorted(n for n in archive.namelist() if n.lower().endswith(".xlsb"))
        tasks = []
        for name in names:
            m = re.search(r"Attachment (\d+)\. Heat No\. (\w+)\.xlsb$", name)
            if not m:
                raise ValueError(f"Unexpected workbook name: {name}")
            attachment, heat = int(m.group(1)), m.group(2)
            workbook_path = Path(tmp) / f"{heat}.xlsb"
            npz_path = Path(tmp) / f"{heat}.npz"
            workbook_path.write_bytes(archive.read(name))
            tasks.append((name, attachment, heat, workbook_path, npz_path))
        import subprocess, sys
        # Run a few isolated XLSB readers concurrently to avoid pyxlsb state
        # accumulation while keeping memory bounded.
        for offset in range(0, len(tasks), 3):
            batch = tasks[offset:offset + 3]
            procs = []
            for name, attachment, heat, workbook_path, npz_path in batch:
                print(f"Loading {name}", flush=True)
                procs.append(subprocess.Popen([sys.executable, str(Path(__file__).resolve()),
                                               "--worker", str(workbook_path),
                                               "--worker-output", str(npz_path)]))
            for proc in procs:
                code = proc.wait()
                if code != 0:
                    raise RuntimeError(f"XLSB worker failed with exit code {code}")
            for name, attachment, heat, workbook_path, npz_path in batch:
                with np.load(npz_path) as z:
                    oxygen = z["oxygen"].copy()
                    gas = z["gas"].copy()
                    oxygen_header = str(z["oxygen_header"].item())
                if len(oxygen) not in range(700, 1700):
                    raise ValueError(f"Unexpected row count in {heat}: {len(oxygen)}")
                heats[heat] = {"attachment": attachment, "oxygen": oxygen, "gas": gas,
                               "file": name, "oxygen_header": oxygen_header}
                workbook_path.unlink(missing_ok=True)
                npz_path.unlink(missing_ok=True)
                print(f"Loaded {heat}: {len(oxygen)} rows", flush=True)
    if len(heats) != 10 or sum(len(v["oxygen"]) for v in heats.values()) != 13589:
        raise ValueError("Official ten-heat coverage check failed")
    return digest, heats


def terminal_end(oxygen, gas, t):
    n = len(gas)
    peak = np.max(gas, axis=0)
    low = np.all(gas < peak[None, :] * 0.05, axis=1)
    run = int(10 / DT)
    start = max(int(120 / DT), int(0.5 * n))
    for i in range(start, n - run):
        end_idx = min(i + run, n - 1)
        if low[i:i + run].all() and oxygen[end_idx] - oxygen[i] > 1.0:
            return float(t[i]), True
    return float(t[-1]), False


def med(x, t, left, right):
    mask = (t >= left) & (t <= right)
    return float(np.median(x[mask])) if np.any(mask) else float("nan")


def slope_per_min(x, t, left, right):
    mask = (t >= left) & (t <= right)
    if mask.sum() < 5:
        return float("nan")
    return float(theilslopes(x[mask], t[mask]).slope * 60.0)


def analyze(heats, outdir):
    unit_rows, tail_rows, sens_rows = [], [], []
    all_values = []
    for heat, d in sorted(heats.items(), key=lambda kv: kv[1]["attachment"]):
        oxygen = d["oxygen"]
        raw_gas = d["gas"]
        t = np.arange(len(oxygen), dtype=float) * DT
        gas = median_filter(raw_gas, size=(11, 1), mode="nearest")
        q_o2 = median_filter(np.gradient(oxygen, DT), size=11, mode="nearest")
        co2, co = gas.T
        cox = co2 + co
        pco2 = co2 / np.maximum(cox, 1e-9)
        # Conditional stoichiometric oxygen equivalent IF both gas channels
        # were actual volume-flow rates on the same reference basis as O2.
        o2eq_if_flow = co2 + 0.5 * co
        o2_total = float(oxygen[-1] - oxygen[0])
        o2eq_integral = float(np.sum(o2eq_if_flow) * DT)
        end, collapse = terminal_end(oxygen, gas, t)
        start_left, start_right = end - 70.0, end - 60.0
        end_left, end_right = end - 10.0, end
        q_start, q_end = med(q_o2, t, start_left, start_right), med(q_o2, t, end_left, end_right)
        co2_start, co2_end = med(co2, t, start_left, start_right), med(co2, t, end_left, end_right)
        co_start, co_end = med(co, t, start_left, start_right), med(co, t, end_left, end_right)
        cox_start, cox_end = med(cox, t, start_left, start_right), med(cox, t, end_left, end_right)
        p_start, p_end = med(pco2, t, start_left, start_right), med(pco2, t, end_left, end_right)
        oi = int(np.clip(np.searchsorted(t, start_left), 0, len(oxygen)-1))
        oe = int(np.clip(np.searchsorted(t, end), 0, len(oxygen)-1))
        progress_start = float((oxygen[oi] - oxygen[0]) / max(o2_total, 1e-9))
        progress_end = float((oxygen[oe] - oxygen[0]) / max(o2_total, 1e-9))
        row = {
            "heat": heat, "attachment": d["attachment"], "oxygen_column_label_raw": d["oxygen_header"], "n_rows": len(oxygen),
            "duration_s_H0": float(t[-1]), "oxygen_total_m3": o2_total,
            "oxygen_rate_median_m3_s_est": float(np.median(q_o2)),
            "gas_CO2_channel_median": float(np.median(co2)),
            "gas_CO_channel_median": float(np.median(co)),
            "gas_COx_sum_channel_median": float(np.median(cox)),
            "gas_COx_sum_channel_max": float(np.max(cox)),
            "o2eq_if_flow_integral_m3": o2eq_integral,
            "o2eq_if_flow_over_lance_O2": o2eq_integral / max(o2_total, 1e-9),
            "o2eq_if_flow_rate_ratio_median": float(np.median(o2eq_if_flow / np.maximum(q_o2, 0.1))),
        }
        unit_rows.append(row)
        tail = {
            "heat": heat, "attachment": d["attachment"], "tail_end_s": end,
            "terminal_collapse_flag": collapse,
            "tail_start_oxygen_progress": progress_start,
            "tail_end_oxygen_progress": progress_end,
            "qO2_start10_m3_s_est": q_start, "qO2_end10_m3_s_est": q_end,
            "qO2_change_pct": 100.0 * (q_end / max(q_start, 1e-9) - 1.0),
            "CO2_start10_channel": co2_start, "CO2_end10_channel": co2_end,
            "CO2_change_channel": co2_end - co2_start,
            "CO_start10_channel": co_start, "CO_end10_channel": co_end,
            "CO_change_channel": co_end - co_start,
            "COx_sum_start10_channel": cox_start, "COx_sum_end10_channel": cox_end,
            "COx_sum_change_channel": cox_end - cox_start,
            "apparent_CO2_share_start": p_start, "apparent_CO2_share_end": p_end,
            "apparent_CO2_share_change": p_end - p_start,
            "CO2_slope_tail60_channel_per_min": slope_per_min(co2, t, end - 60, end),
            "CO_slope_tail60_channel_per_min": slope_per_min(co, t, end - 60, end),
            "COx_sum_slope_tail60_channel_per_min": slope_per_min(cox, t, end - 60, end),
            "apparent_CO2_share_slope_tail60_per_min": slope_per_min(pco2, t, end - 60, end),
        }
        tail_rows.append(tail)
        for window in (30, 45, 60, 90):
            sens_rows.append({
                "heat": heat, "window_s": window,
                "CO2_slope_channel_per_min": slope_per_min(co2, t, end-window, end),
                "CO_slope_channel_per_min": slope_per_min(co, t, end-window, end),
                "COx_sum_slope_channel_per_min": slope_per_min(cox, t, end-window, end),
                "apparent_CO2_share_slope_per_min": slope_per_min(pco2, t, end-window, end),
                "qO2_slope_m3_s_per_min_est": slope_per_min(q_o2, t, end-window, end),
            })
        all_values.append({"heat": heat, "gas_min": float(np.min(gas)), "gas_max": float(np.max(gas)),
                           "COx_max": float(np.max(cox))})

    unit_df = pd.DataFrame(unit_rows).sort_values("attachment")
    tail_df = pd.DataFrame(tail_rows).sort_values("attachment")
    sens_df = pd.DataFrame(sens_rows).sort_values(["heat", "window_s"])
    unit_df.to_csv(outdir / "measurement_semantics_audit.csv", index=False, float_format="%.8g")
    tail_df.to_csv(outdir / "tail_composition_oxygen_audit.csv", index=False, float_format="%.8g")
    sens_df.to_csv(outdir / "tail_window_sensitivity.csv", index=False, float_format="%.8g")
    summary = {
        "heats": 10, "rows": int(unit_df.n_rows.sum()), "dt_s": DT,
        "gas_column_header_raw": ["CO2浓度 / CO₂ concentration", "CO浓度 / CO concentration"],
        "oxygen_column_header_labels": sorted(set(d["oxygen_header"] for d in heats.values())),
        "gas_units_status": "ambiguous in problem statement; do not treat as flow without plant metadata",
        "conditional_flow_assumption_o2eq_over_lance_o2": {
            "min": float(unit_df.o2eq_if_flow_over_lance_O2.min()),
            "median": float(unit_df.o2eq_if_flow_over_lance_O2.median()),
            "max": float(unit_df.o2eq_if_flow_over_lance_O2.max()),
        },
        "tail_start_oxygen_progress_median": float(tail_df.tail_start_oxygen_progress.median()),
        "tail_start_oxygen_progress_range": [float(tail_df.tail_start_oxygen_progress.min()), float(tail_df.tail_start_oxygen_progress.max())],
        "tail_sign_counts_endpoint_comparison": {
            "CO2_up": int((tail_df.CO2_change_channel > 0).sum()),
            "CO_down": int((tail_df.CO_change_channel < 0).sum()),
            "COx_sum_down": int((tail_df.COx_sum_change_channel < 0).sum()),
            "apparent_CO2_share_up": int((tail_df.apparent_CO2_share_change > 0).sum()),
        },
        "tail_median_endpoint_changes": {
            "CO2_channel": float(tail_df.CO2_change_channel.median()),
            "CO_channel": float(tail_df.CO_change_channel.median()),
            "COx_sum_channel": float(tail_df.COx_sum_change_channel.median()),
            "apparent_CO2_share": float(tail_df.apparent_CO2_share_change.median()),
        },
        "oxygen_rate_endpoint_change_pct": {
            "median_all_heats": float(tail_df.qO2_change_pct.median()),
            "n_abs_change_le_5pct": int((tail_df.qO2_change_pct.abs() <= 5).sum()),
            "values": {r.heat: float(r.qO2_change_pct) for r in tail_df.itertuples()},
        },
        "interpretation": [
            "The flow-rate interpretation fails a conditional oxygen-stoichiometry feasibility check if gas channels share the O2 volume reference basis.",
            "Gas channels are labeled concentrations and their numerical ranges are composition-like; volume-percent interpretation is plausible but must be confirmed from plant metadata.",
            "CO2/(CO+CO2) is an apparent CO2 share, not a complete post-combustion ratio when H2 and H2O are unavailable.",
            "CO+CO2 channel sum is not total carbon emission unless total off-gas flow is known.",
        ],
    }
    (outdir / "run_manifest.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return unit_df, tail_df, sens_df, summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data-zip", type=Path)
    p.add_argument("--output-dir", type=Path)
    p.add_argument("--worker", type=Path, help=argparse.SUPPRESS)
    p.add_argument("--worker-output", type=Path, help=argparse.SUPPRESS)
    args = p.parse_args()
    if args.worker is not None:
        if args.worker_output is None:
            raise ValueError("--worker-output is required with --worker")
        _read_one_workbook(args.worker, args.worker_output)
        return
    if args.data_zip is None or args.output_dir is None:
        p.error("--data-zip and --output-dir are required")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    digest, heats = read_heats(args.data_zip)
    unit_df, tail_df, sens_df, summary = analyze(heats, args.output_dir)
    summary["data_zip_sha256"] = digest
    (args.output_dir / "run_manifest.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
